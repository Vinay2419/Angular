import { Component } from '@angular/core';
import { IProduct } from './product';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
    selector: 'pm-products',
    templateUrl: './product-list.component.html',
    styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit{
    
    pageTitle: string = 'Product List!';
    imagewidth: number = 100;
    imageMargin: number = 4;
    showImage: boolean = false;
    listFilter: string = ' cart';
    products: IProduct[] = [
        {
            "productId": 2,
            "productName": "Detergent  ",
            "productCode": "VK-0001",
            "releaseDate": "Jan 01,2018",
            "description": "15 Litres",
            "price": 1.11,
            "starRating": 4.3,
            "imageUrl": "http://www.ccspa.org/site/wp-content/uploads/2012/06/CCSPA-Products-reflections.jpg"
        },
        {
            "productId": 3,
            "productName": "All out",
            "productCode": "VK-0002",
            "releaseDate": "Feb 02,2018",
            "description": "50 mL",
            "price": 80.9,
            "starRating": 3.3,
            "imageUrl": "https://scjdmcdn.azureedge.net/~/media/raid/products/products-hero.png?la=en-IN&hash=4BDED89855E2B84703D83595BCB944AB081BCC63"
        },
        {
            "productId": 3,
            "productName": "Kinder Joy",
            "productCode": "VK-0003",
            "releaseDate": "March 03,2018",
            "description": "Small",
            "price": 40.0,
            "starRating": 4.9,
            "imageUrl": "https://files.brightside.me/files/news/part_42/426960/18434910-Depositphotos_96023798_xl-2015-1513595556-650-47344d3213-1514622501.jpg"
        },
        {
            "productId": 4,
            "productName": "Chips",
            "productCode": "VK-0004",
            "releaseDate": "March 03,2018",
            "description": "Small",
            "price": 40.0,
            "starRating": 3.5,
            "imageUrl": "https://www.familydollar.com/content/dam/familydollar/products-services/products-module-image.jpg"
        }
    ];

    toggleImage(): void{
        this.showImage = !this.showImage;
    }

    ngOnInit(): void {
        console.log('Here OnInIt');
    }
}
import { Pipe } from "@angular/core";
import { PipeTransform } from "@angular/core/src/change_detection/pipe_transform";

@Pipe({
    name: 'convertToSpaces'

})
export class ConvertTospacesPipe implements PipeTransform{
    
    transform(value: string, character: string) : string {
        return value.replace(character, ' ');
    }
}